## Caculate VM datatransfer

### **Usage**
Dùng để tính toán lượng data transfer đi ra trên đường WAN của các VM

### **Guide**
- Trên node controller của OpenStack, thêm user và phân quyền truy cập database của **Neutron**:
    ```
    # mysql -u root -p
    > CREATE USER 'python-test'@'%' IDENTIFIED BY 'Password123';
    > GRANT SELECT ON neutron.ports TO 'python-test'@'%';
    > GRANT SELECT ON neutron.networks TO 'python-test'@'%';
    > FLUSH PRIVILEGES;
    > exit;
    ```
- Cài đặt **Diamond** trên các node compute và cấu hình gửi dữ liệu về node thu thập dữ liệu (**InfluxDB**).
- Trên node thu thập dữ liệu, cài đặt các thư viện cần thiết trong file `requirements.txt` (nên sử dụng `virtualenv`).
    - Cài đặt `virtualenv` :
        ```
        # pip install virtualenv
        # cd vm-datatransfer
        # virtualenv -p /usr/bin/python3.6 env
        # source env/bin/activate
        ```
- Trên node thu thập dữ liệu, tạo database để lưu thông tin data transfer :
    ```
    # influx
    > create database diamond
    ```
- Trên node thu thập dữ liệu, chạy script `hourly_script.py` để thu thập dữ liệu theo giờ và gửi data đến **MongoDB**.
- Trên node cài **MongoDB**, chạy các script `daily_script.py` (tính toán data theo ngày), `monthly_script.py` (tính toán data theo tháng)
- Có thể tự động hóa các công việc trên bằng crontab :
```
@hourly <path_to_env> <path>/hourly_script.py

@daily <path_to_env> <path>/daily_script.py

@monthly <path_to_env> <path>/monthly_script.py
```
### **Configuration**
```yaml
# MariaDB (OpenStack) info
MARIADB_HOST: '10.10.230.10'            # IP controller OpenStack
MARIADB_PORT: 3306                      # Port MariaDB
MARIADB_USER: 'python-test'             # User đã được cấp quyền truy cập DB Neutron
MARIADB_PASSWORD: 'Password123'
MARIADB_DB_NAME: 'neutron'

# InfluxDB info
INFLUXDB_HOST: 'localhost'
INFLUXDB_PORT: 8086
INFLUXDB_USER: 'pythontest'
INFLUXDB_PASSWORD: 'Password123'
INFLUXDB_DB_NAME: 'diamond' 

# MongoDB info
MONGODB_HOST: 'localhost'
MONGODB_PORT: 27017
MONGODB_USER: 'pythontest'
MONGODB_PASSWORD: 'Password123'
MONGO_DB_NAME: 'mydatabase'                  # Tên database chứa thông tin data transfer
COL_NAME_HOUR: "datatransfer"                # Tên collection chứa thông tin data transfer thu thâp theo giờ
COL_NAME_DAY: "datatransfer_day"             # Tên collection chứa thông tin data transfer thu thâp theo ngày
COL_NAME_MONTH: "datatransfer_month"         # Tên collection chứa thông tin data transfer thu thâp theo tháng
```