import os
import sys

import yaml

with open("{}/app.yaml".format(os.path.dirname(__file__)), 'r') as stream:
    try:
        config_file = yaml.load(stream)
    except Exception as e:
        sys.exit(str(e))


def _get_config_value(key, default_value=None):
    try:
        default_value = config_file.get(key, default_value)
    except:
        pass

    return os.environ.get(key, default_value)

class BaseConfig(object):
    
    # MariaDB (OpenStack)
    MARIADB_HOST = _get_config_value('MARIADB_HOST')
    MARIADB_PORT = _get_config_value('MARIADB_PORT', '3306')
    MARIADB_USER = _get_config_value('MARIADB_USER')
    MARIADB_PASSWORD = _get_config_value('MARIADB_PASSWORD')
    MARIADB_DB_NAME = _get_config_value('MARIADB_DB_NAME', 'neutron')

    # InfluxDB
    INFLUXDB_HOST = _get_config_value('INFLUXDB_HOST')
    INFLUXDB_PORT = _get_config_value('INFLUXDB_PORT')
    INFLUXDB_USER = _get_config_value('INFLUXDB_USER')
    INFLUXDB_PASSWORD = _get_config_value('INFLUXDB_PASSWORD')
    INFLUXDB_DB_NAME = _get_config_value('INFLUXDB_DB_NAME')

    # MongoDB
    MONGODB_HOST = _get_config_value('MONGODB_HOST')
    MONGODB_PORT = _get_config_value('MONGODB_PORT')
    MONGODB_USER = _get_config_value('MONGODB_USER')
    MONGODB_PASSWORD = _get_config_value('MONGODB_PASSWORD')
    MONGO_DB_NAME = _get_config_value('MONGO_DB_NAME')
    COL_NAME_HOUR = _get_config_value('COL_NAME_HOUR')
    COL_NAME_DAY = _get_config_value('COL_NAME_DAY')
    COL_NAME_MONTH = _get_config_value('COL_NAME_MONTH')


class Development(BaseConfig):
    pass

config = {
    'development': Development
}    